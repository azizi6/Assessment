// const axios = require('axios');

// exports.handler = async (event, context) => {
//     // Extract the address from query parameters
//     const address = event.queryStringParameters.address;
//     if (!address) {
//         return {
//             statusCode: 400,
//             body: JSON.stringify({ error: 'Missing address parameter' }),
//         };
//     }

//     // Ngrok URL of your Express app
//     const ngrokUrl = 'https://98ac-112-141-2-235.ngrok-free.app';

//     try {
//         // Make an HTTP GET request to your Express app with the address parameter
//         console.log("axiosss urlll",`${ngrokUrl}/api/query?address=${encodeURIComponent(address)}`);
//         const response = await axios.get(`${ngrokUrl}/api/query?address=${encodeURIComponent(address)}`);
//         console.log("axios resppp:",response);
//         const data = response.data;
//         console.log("DATTTAAAA:",data);

//         // Process the data as needed
        
//         return {
//             statusCode: 200,
//             body: JSON.stringify(data),
//         };
//     } catch (error) {
//         console.error(error);
//         return {
//             statusCode: 500,
//             body: JSON.stringify({ error: 'Internal Server Error' }),
//         };
//     }
// };


// const axios = require('axios');

// exports.handler = async (event, context) => {
//     // Extract the address from query parameters
//     const address = event.queryStringParameters.address;
//     if (!address) {
//         return {
//             statusCode: 400,
//             body: JSON.stringify({ error: 'Missing address parameter' }),
//         };
//     }

//     // Define the URL with the specific query parameters
//     const url = `https://portal.spatial.nsw.gov.au/server/rest/services/NSW_Geocoded_Addressing_Theme/FeatureServer/1/query?where=address+%3D+%27${encodeURIComponent(address)}%27&outFields=*&f=geojson`;

//     try {
//         // Make an HTTP GET request to the new URL
//         console.log("axiosss urlll", url);
//         const response = await axios.get(url);
//         console.log("axios resppp:", response);

//         // Access the GeoJSON data
//         const data = response.data;
//         console.log("DATTTAAAA:", data);

//         // Access the coordinates of the first feature
//         if (data.features && data.features.length > 0) {
//             const coordinates = data.features[0].geometry.coordinates;
//             console.log("Coordinates:", coordinates);
//         } else {
//             console.log("No features found in the response.");
//         }

//         // Process the data as needed

//         return {
//             statusCode: 200,
//             body: JSON.stringify(data),
//         };
//     } catch (error) {
//         console.error(error);
//         return {
//             statusCode: 500,
//             body: JSON.stringify({ error: 'Internal Server Error' }),
//         };
//     }
// };


const axios = require('axios');

exports.handler = async (event, context) => {
    // Extract the address from query parameters
    const address = event.queryStringParameters.address;
    if (!address) {
        return {
            statusCode: 400,
            body: JSON.stringify({ error: 'Missing address parameter' }),
        };
    }

    // Define the URL with the specific query parameters to get GeoJSON data based on the address
    const addressQueryUrl = `https://portal.spatial.nsw.gov.au/server/rest/services/NSW_Geocoded_Addressing_Theme/FeatureServer/1/query?where=address+%3D+%27${encodeURIComponent(address)}%27&outFields=*&f=geojson`;

    try {
        // Make an HTTP GET request to the address query URL
        console.log("axiosss urlll", addressQueryUrl);
        const addressResponse = await axios.get(addressQueryUrl);
        console.log("axios addressResponse:", addressResponse);

        // Access the GeoJSON data
        const addressData = addressResponse.data;
        console.log("Address Data:", addressData);

        // Initialize variables to store coordinates, districtname, and suburbName
        let coordinates = null;
        let districtName = null;
        let suburbName = null;

        // Access the coordinates of the first feature
        if (addressData.features && addressData.features.length > 0) {
            coordinates = addressData.features[0].geometry.coordinates;
            console.log("Coordinates:", coordinates);

            // Extract the suburb name from the given address (last part of the address)
            const addressParts = address.split(' ');
            suburbName = addressParts[addressParts.length - 1];
            console.log("Suburb Name:", suburbName);
        } else {
            console.log("No features found in the address query response.");
            return {
                statusCode: 500,
                body: JSON.stringify({ error: 'No features found for the given address' }),
            };
        }

        // Define the URL for the second query based on the obtained coordinates
        const secondQueryUrl = `https://portal.spatial.nsw.gov.au/server/rest/services/NSW_Administrative_Boundaries_Theme/FeatureServer/4/query?geometry=${coordinates[0]}%2C${coordinates[1]}&geometryType=esriGeometryPoint&inSR=4326&spatialRel=esriSpatialRelIntersects&outFields=*&returnGeometry=false&f=geoJSON`;

        // Make an HTTP GET request to the second query URL
        console.log("axios secondQueryUrl", secondQueryUrl);
        const secondResponse = await axios.get(secondQueryUrl);
        console.log("axios secondResponse:", secondResponse);

        // Access the GeoJSON data from the second query
        const secondData = secondResponse.data;
        console.log("Second Query Data:", secondData);

        // Access the districtname property from the GeoJSON data
        if (secondData.features && secondData.features.length > 0) {
            districtName = secondData.features[0].properties.districtname;
            console.log("District Name:", districtName);
        }

        // Construct the response object with coordinates, districtname, and suburbName
        const responseObject = {
            coordinates: coordinates,
            districtName: districtName,
            suburbName: suburbName,
        };

        // Process the data as needed

        return {
            statusCode: 200,
            body: JSON.stringify(responseObject),
        };
    } catch (error) {
        console.error(error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal Server Error' }),
        };
    }
};
